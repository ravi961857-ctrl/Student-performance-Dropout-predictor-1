import io
import os
import sqlite3
import zipfile
from datetime import datetime

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests
import streamlit as st
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------
st.set_page_config(
    page_title="Student Dropout Risk Analytics",
    page_icon="🎓",
    layout="wide",
)

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "student_history.db")
DATA_URL = (
    "https://archive.ics.uci.edu/static/public/697/"
    "predict+students+dropout+and+academic+success.zip"
)
TARGET_COLUMN = "Target"
RANDOM_STATE = 42

st.markdown("""
<style>
.block-container {padding-top: 1.5rem; padding-bottom: 2rem;}
[data-testid="stMetric"] {
  border: 1px solid rgba(128,128,128,.25);
  padding: 12px; border-radius: 12px;
}
</style>
""", unsafe_allow_html=True)


# ------------------------------------------------------------
# Data and model training
# ------------------------------------------------------------
@st.cache_data(show_spinner=False)
def load_dataset():
    response = requests.get(DATA_URL, timeout=60)
    response.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        candidates = [
            name for name in archive.namelist()
            if os.path.basename(name).lower() == "data.csv"
        ]
        if not candidates:
            raise ValueError("Could not find data.csv in the UCI dataset archive.")
        with archive.open(candidates[0]) as file:
            data = pd.read_csv(file, sep=";")
    if TARGET_COLUMN not in data.columns:
        raise ValueError(
            "The downloaded dataset does not contain the expected Target column."
        )
    data = data.dropna(subset=[TARGET_COLUMN]).copy()
    data[TARGET_COLUMN] = data[TARGET_COLUMN].astype(str).str.strip()
    return data


def make_preprocessor(feature_columns):
    # UCI dataset predictors are numeric coded variables.
    return ColumnTransformer(
        transformers=[
            ("numeric", Pipeline([
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
            ]), feature_columns)
        ],
        remainder="drop",
    )


@st.cache_resource(show_spinner=False)
def train_models():
    data = load_dataset()
    feature_columns = [c for c in data.columns if c != TARGET_COLUMN]

    # Genuine dataset outcome: Dropout vs not labelled Dropout.
    # "Enrolled" is not a confirmed graduate outcome; see limitations in UI.
    y = (data[TARGET_COLUMN] == "Dropout").astype(int)
    X = data[feature_columns].apply(pd.to_numeric, errors="coerce")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y
    )

    algorithms = {
        "Logistic Regression": LogisticRegression(
            max_iter=3000, class_weight="balanced", random_state=RANDOM_STATE
        ),
        "Decision Tree": DecisionTreeClassifier(
            max_depth=8, min_samples_leaf=10,
            class_weight="balanced", random_state=RANDOM_STATE
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=250, max_depth=12, min_samples_leaf=3,
            class_weight="balanced_subsample", random_state=RANDOM_STATE,
            n_jobs=-1
        ),
    }

    models = {}
    metric_rows = []
    test_predictions = {}
    for name, algorithm in algorithms.items():
        model = Pipeline([
            ("preprocessor", make_preprocessor(feature_columns)),
            ("classifier", algorithm),
        ])
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        models[name] = model
        test_predictions[name] = pred
        metric_rows.append({
            "Model": name,
            "Accuracy (%)": round(accuracy_score(y_test, pred) * 100, 2),
            "Precision (%)": round(precision_score(y_test, pred, zero_division=0) * 100, 2),
            "Recall (%)": round(recall_score(y_test, pred, zero_division=0) * 100, 2),
            "F1 Score (%)": round(f1_score(y_test, pred, zero_division=0) * 100, 2),
        })

    return data, feature_columns, models, pd.DataFrame(metric_rows), X_test, y_test, test_predictions


# ------------------------------------------------------------
# Local SQLite prediction history
# ------------------------------------------------------------
def init_database():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                student_id TEXT,
                student_name TEXT,
                model TEXT NOT NULL,
                risk_probability REAL NOT NULL,
                risk_level TEXT NOT NULL,
                prediction TEXT NOT NULL
            )
        """)


def save_prediction(record):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            INSERT INTO predictions
            (created_at, student_id, student_name, model,
             risk_probability, risk_level, prediction)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            record["created_at"], record["student_id"], record["student_name"],
            record["model"], record["risk_probability"], record["risk_level"],
            record["prediction"]
        ))


def load_history():
    with sqlite3.connect(DB_PATH) as conn:
        return pd.read_sql_query(
            "SELECT * FROM predictions ORDER BY id DESC", conn
        )


def get_risk_level(probability):
    # Adjustable demonstration bands; not validated institutional thresholds.
    if probability < 0.30:
        return "Low"
    if probability < 0.60:
        return "Medium"
    return "High"


def create_pdf_report(record):
    buffer = io.BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    y = height - 65

    pdf.setTitle("Student Dropout Risk Assessment")
    pdf.setFont("Helvetica-Bold", 18)
    pdf.drawString(48, y, "Student Dropout Risk Assessment")
    y -= 32

    pdf.setFont("Helvetica", 11)
    lines = [
        f"Generated: {record['created_at']}",
        f"Student ID: {record['student_id'] or 'Not provided'}",
        f"Student name: {record['student_name'] or 'Not provided'}",
        f"Selected model: {record['model']}",
        f"Prediction: {record['prediction']}",
        f"Risk band: {record['risk_level']}",
        f"Estimated dropout probability: {record['risk_probability']:.2f}%",
        "",
        "Interpretation and limitations",
        "This is a machine-learning estimate, not a guaranteed outcome.",
        "Risk bands are demonstration thresholds and are not validated cutoffs.",
        "The UCI dataset includes Dropout, Enrolled and Graduate outcomes.",
        "This binary version labels Dropout as positive and other labels as not Dropout.",
        "Use predictions only to support human review and student support.",
    ]
    for line in lines:
        if y < 55:
            pdf.showPage()
            y = height - 55
            pdf.setFont("Helvetica", 11)
        pdf.drawString(48, y, line[:110])
        y -= 22
    pdf.save()
    buffer.seek(0)
    return buffer.getvalue()


# ------------------------------------------------------------
# Application
# ------------------------------------------------------------
st.title("🎓 Student Performance & Dropout Predictor")
st.caption("Machine learning • Academic risk analytics • UCI real dropout outcome dataset")

try:
    with st.spinner("Downloading the UCI dataset and training three models. First launch may take a minute..."):
        data, feature_columns, models, metrics, X_test, y_test, test_predictions = train_models()
    init_database()
except Exception as exc:
    st.error("The dataset or models could not be loaded.")
    st.markdown(
        "Check your internet connection, then restart the app. "
        "The first launch downloads the public UCI dataset."
    )
    st.code(str(exc))
    st.stop()

# Main target distribution
dropout_count = int((data[TARGET_COLUMN] == "Dropout").sum())
graduate_count = int((data[TARGET_COLUMN] == "Graduate").sum())
enrolled_count = int((data[TARGET_COLUMN] == "Enrolled").sum())

with st.sidebar:
    st.header("Navigation")
    page = st.radio(
        "Choose a page",
        ["Dashboard", "Predict Student", "Bulk Prediction", "Prediction History", "Model Insights"]
    )
    selected_model = st.selectbox("Prediction model", list(models.keys()), index=2)
    st.divider()
    st.caption("Dataset: UCI Predict Students' Dropout and Academic Success")
    st.caption(f"Records loaded: {len(data):,}")
    st.caption("Local prediction history is stored in student_history.db.")

# This dataset has numeric-coded admission and academic features.
# Use sensible defaults based on medians and expose key variables in the form.
def make_default_row():
    X = data[feature_columns].apply(pd.to_numeric, errors="coerce")
    row = {}
    for column in feature_columns:
        if X[column].notna().any():
            row[column] = float(X[column].median())
        else:
            row[column] = 0.0
    return row


if page == "Dashboard":
    st.header("Dashboard Overview")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total records", f"{len(data):,}")
    c2.metric("Dropout records", f"{dropout_count:,}")
    c3.metric("Graduate records", f"{graduate_count:,}")
    c4.metric("Enrolled records", f"{enrolled_count:,}")

    left, right = st.columns(2)
    with left:
        st.subheader("Dataset outcome distribution")
        outcome_counts = data[TARGET_COLUMN].value_counts().reindex(
            ["Dropout", "Enrolled", "Graduate"], fill_value=0
        )
        fig, ax = plt.subplots(figsize=(7, 4))
        ax.bar(outcome_counts.index, outcome_counts.values)
        ax.set_ylabel("Number of records")
        ax.set_title("Original UCI outcomes")
        st.pyplot(fig)
        plt.close(fig)

    with right:
        st.subheader("Model comparison")
        st.dataframe(metrics, hide_index=True, use_container_width=True)
        fig, ax = plt.subplots(figsize=(7, 4))
        ax.bar(metrics["Model"], metrics["Recall (%)"])
        ax.set_ylabel("Recall (%)")
        ax.set_title("Dropout-class recall on held-out test set")
        ax.tick_params(axis="x", rotation=15)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close(fig)

    st.info(
        "This project uses actual UCI outcome labels. For the binary model, "
        "'Dropout' is the positive class, while 'Enrolled' and 'Graduate' are grouped "
        "as not labelled Dropout. Enrolled students are not necessarily confirmed graduates."
    )

elif page == "Predict Student":
    st.header("Individual Student Prediction")
    st.write(
        "Enter the available student details. The UCI dataset uses coded admission, "
        "demographic and semester-performance features. Unedited features are filled "
        "with dataset medians for this prototype."
    )

    # Feature names are displayed exactly as they appear in the UCI data.
    # The form lets users edit important, understandable features and fills the rest.
    preferred_features = [
        "Age at enrollment",
        "Admission grade",
        "Previous qualification (grade)",
        "Curricular units 1st sem (approved)",
        "Curricular units 1st sem (grade)",
        "Curricular units 2nd sem (approved)",
        "Curricular units 2nd sem (grade)",
        "Tuition fees up to date",
        "Scholarship holder",
        "Debtor",
        "Gender",
        "Displaced",
    ]
    available_preferred = [f for f in preferred_features if f in feature_columns]
    defaults = make_default_row()

    with st.form("prediction_form"):
        student_id = st.text_input("Student ID (optional)", placeholder="STU001")
        student_name = st.text_input("Student name (optional)", placeholder="Student name")
        st.caption("Fields not shown below use median values from the training dataset.")
        edited = {}
        columns = st.columns(2)
        for idx, feature in enumerate(available_preferred):
            with columns[idx % 2]:
                min_val = float(pd.to_numeric(data[feature], errors="coerce").min())
                max_val = float(pd.to_numeric(data[feature], errors="coerce").max())
                default_val = float(defaults[feature])
                if feature in [
                    "Tuition fees up to date", "Scholarship holder", "Debtor",
                    "Gender", "Displaced"
                ]:
                    choices = sorted(pd.to_numeric(data[feature], errors="coerce").dropna().unique().tolist())
                    if len(choices) <= 10 and choices:
                        edited[feature] = st.selectbox(
                            feature, choices,
                            index=choices.index(min(choices, key=lambda x: abs(x - default_val)))
                        )
                    else:
                        edited[feature] = st.number_input(
                            feature, min_value=min_val, max_value=max_val, value=default_val
                        )
                else:
                    edited[feature] = st.number_input(
                        feature, min_value=min_val, max_value=max_val,
                        value=default_val, step=1.0
                    )
        submitted = st.form_submit_button("Predict Dropout Risk", type="primary", use_container_width=True)

    if submitted:
        row = defaults.copy()
        row.update(edited)
        sample = pd.DataFrame([row], columns=feature_columns)
        model = models[selected_model]
        probability = float(model.predict_proba(sample)[0][1] * 100)
        predicted_dropout = int(model.predict(sample)[0]) == 1
        risk_level = get_risk_level(probability)
        prediction_label = "Predicted dropout risk" if predicted_dropout else "Not predicted as dropout"

        record = {
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "student_id": student_id.strip(),
            "student_name": student_name.strip(),
            "model": selected_model,
            "risk_probability": probability,
            "risk_level": risk_level,
            "prediction": prediction_label,
        }

        st.subheader("Prediction Result")
        a, b, c = st.columns(3)
        a.metric("Estimated dropout probability", f"{probability:.1f}%")
        b.metric("Risk band", risk_level)
        c.metric("Selected model", selected_model)

        if predicted_dropout:
            st.warning("The selected model flags this record as possible dropout risk.")
        else:
            st.success("The selected model does not classify this record as dropout.")

        st.progress(int(np.clip(probability, 0, 100)))
        st.caption(
            "The probability is a model estimate. The editable fields are only a subset; "
            "remaining inputs are imputed using dataset medians. Do not use this as a sole decision."
        )

        save_prediction(record)
        st.success("Prediction saved in the local SQLite history.")

        pdf_bytes = create_pdf_report(record)
        safe_id = "".join(ch for ch in (student_id.strip() or "student") if ch.isalnum() or ch in "-_")
        st.download_button(
            "Download PDF report",
            data=pdf_bytes,
            file_name=f"dropout_report_{safe_id}.pdf",
            mime="application/pdf",
        )

        with st.expander("Show model input values"):
            st.dataframe(sample.T.rename(columns={0: "Input value"}), use_container_width=True)

elif page == "Bulk Prediction":
    st.header("Bulk Prediction")
    st.write(
        "Upload a CSV containing the same feature columns as the UCI dataset. "
        "A downloadable template is provided below."
    )

    template = data[feature_columns].head(1).copy()
    st.download_button(
        "Download CSV template (all required features)",
        data=template.to_csv(index=False).encode("utf-8"),
        file_name="student_features_template.csv",
        mime="text/csv",
    )
    uploaded = st.file_uploader("Upload student feature CSV", type=["csv"])
    if uploaded is not None:
        try:
            batch = pd.read_csv(uploaded)
            missing = [column for column in feature_columns if column not in batch.columns]
            if missing:
                st.error("Missing required feature columns: " + ", ".join(missing[:15]) +
                         (" ..." if len(missing) > 15 else ""))
            elif batch.empty:
                st.warning("The uploaded CSV is empty.")
            else:
                X_batch = batch[feature_columns].apply(pd.to_numeric, errors="coerce")
                model = models[selected_model]
                preds = model.predict(X_batch)
                probs = model.predict_proba(X_batch)[:, 1] * 100
                results = batch.copy()
                results["Predicted outcome"] = np.where(
                    preds == 1, "Dropout risk", "Not classified as dropout"
                )
                results["Dropout probability (%)"] = np.round(probs, 2)
                results["Risk band"] = [get_risk_level(p) for p in probs]
                st.success(f"Predictions completed for {len(results)} rows.")
                st.dataframe(results, use_container_width=True, hide_index=True)
                st.download_button(
                    "Download prediction results",
                    data=results.to_csv(index=False).encode("utf-8"),
                    file_name="student_dropout_predictions.csv",
                    mime="text/csv",
                )
        except Exception as exc:
            st.error(f"Could not process this CSV: {exc}")

elif page == "Prediction History":
    st.header("Prediction History")
    history = load_history()
    if history.empty:
        st.info("No prediction history yet. Make a prediction first.")
    else:
        c1, c2 = st.columns(2)
        with c1:
            search_id = st.text_input("Search Student ID")
        with c2:
            risk_filter = st.selectbox("Filter risk band", ["All", "Low", "Medium", "High"])
        filtered = history.copy()
        if search_id.strip():
            filtered = filtered[
                filtered["student_id"].fillna("").str.contains(search_id.strip(), case=False)
            ]
        if risk_filter != "All":
            filtered = filtered[filtered["risk_level"] == risk_filter]
        st.metric("Matching records", len(filtered))
        st.dataframe(filtered, use_container_width=True, hide_index=True)
        st.download_button(
            "Download history CSV",
            data=filtered.to_csv(index=False).encode("utf-8"),
            file_name="student_prediction_history.csv",
            mime="text/csv",
        )

elif page == "Model Insights":
    st.header("Model Insights")
    st.subheader("Compare all algorithms")
    st.dataframe(metrics, use_container_width=True, hide_index=True)

    metric_choice = st.selectbox(
        "Chart metric", ["Accuracy (%)", "Precision (%)", "Recall (%)", "F1 Score (%)"]
    )
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.bar(metrics["Model"], metrics[metric_choice])
    ax.set_ylabel(metric_choice)
    ax.set_title(f"Model comparison: {metric_choice}")
    ax.tick_params(axis="x", rotation=12)
    plt.tight_layout()
    st.pyplot(fig)
    plt.close(fig)

    st.subheader("Confusion Matrix")
    chosen_predictions = test_predictions[selected_model]
    cm = confusion_matrix(y_test, chosen_predictions, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(5, 4))
    im = ax.imshow(cm)
    ax.set_xticks([0, 1], labels=["Not Dropout", "Dropout"])
    ax.set_yticks([0, 1], labels=["Not Dropout", "Dropout"])
    ax.set_xlabel("Predicted label")
    ax.set_ylabel("Actual label")
    ax.set_title(selected_model)
    for r in range(2):
        for c in range(2):
            ax.text(c, r, str(cm[r, c]), ha="center", va="center")
    fig.colorbar(im, ax=ax)
    st.pyplot(fig)
    plt.close(fig)

    st.subheader("Feature importance")
    model = models[selected_model]
    classifier = model.named_steps["classifier"]
    preprocessor = model.named_steps["preprocessor"]
    if hasattr(classifier, "feature_importances_"):
        importance = classifier.feature_importances_
        description = "Tree-based importance reflects how the model used features in splits."
    else:
        importance = np.abs(classifier.coef_[0])
        description = (
            "Absolute Logistic Regression coefficients are a rough importance indicator "
            "after scaling, not causal effects."
        )
    feature_importance = pd.DataFrame({
        "Feature": feature_columns,
        "Importance": importance
    }).sort_values("Importance", ascending=False).head(12)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.barh(feature_importance["Feature"][::-1], feature_importance["Importance"][::-1])
    ax.set_xlabel("Relative importance")
    ax.set_title(f"Top factors — {selected_model}")
    plt.tight_layout()
    st.pyplot(fig)
    plt.close(fig)
    st.caption(description)

    st.subheader("Evaluation details")
    st.code(classification_report(
        y_test, chosen_predictions,
        target_names=["Not labelled Dropout", "Dropout"],
        zero_division=0
    ))

st.divider()
st.caption(
    "Educational prototype • Public UCI dataset • Predictions support human review only. "
    "Risk bands are illustrative and should be validated before real use."
)
