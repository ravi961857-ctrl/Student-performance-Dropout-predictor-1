# Student Performance & Dropout Predictor

A beginner-friendly Streamlit project using the UCI **Predict Students' Dropout and Academic Success** dataset. It trains Logistic Regression, Decision Tree, and Random Forest models.

## Features
- Dashboard with actual UCI outcome counts
- Individual dropout-risk prediction
- Model comparison: accuracy, precision, recall, F1
- Confusion matrix and feature importance
- Bulk CSV predictions and downloadable results
- SQLite prediction history
- Downloadable PDF assessment report

## Important target definition
The dataset has three outcomes: `Dropout`, `Enrolled`, and `Graduate`. This app makes a binary classifier where `Dropout` is the positive class and the other two labels are grouped as “not labelled Dropout”. An `Enrolled` student is not necessarily a confirmed graduate, so interpret the binary target carefully. This is a student-support prototype, not a validated decision tool.

The dataset does not include every field from the original proposal (for example, a direct attendance percentage or weekly study hours). The individual form exposes important features available in this real dropout dataset and fills other feature values with dataset medians. Bulk prediction requires all predictor columns from the dataset.

## Requirements
- Python 3.10 or newer recommended
- Internet connection on first run to download the UCI dataset
- VS Code with Python extension (recommended)

## Run on Windows
1. Extract the project ZIP.
2. Open the extracted `student_dropout_predictor` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:

   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   python -m streamlit run app.py
   ```

5. Open the local URL printed in the terminal, usually `http://localhost:8501`.

If PowerShell blocks activation, use Command Prompt terminal or run `.venv\Scripts\python.exe -m pip install -r requirements.txt` and `.venv\Scripts\python.exe -m streamlit run app.py`.

## Run on macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Data and privacy
The app downloads the dataset from the UCI repository when first run. Prediction history is saved locally in `student_history.db`. Do not commit the database or upload identifiable student data to a public app.

## Project structure
```text
student_dropout_predictor/
├── app.py
├── requirements.txt
├── README.md
├── run_windows.bat
├── run_mac_linux.sh
└── .gitignore
```
