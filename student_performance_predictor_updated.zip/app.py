from flask import Flask, render_template, request, redirect, url_for, flash, make_response, session
import os, sqlite3
from datetime import datetime
import pandas as pd, numpy as np, io, csv
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
app=Flask(__name__); app.secret_key=os.environ.get("FLASK_SECRET_KEY")
if not app.secret_key:
    app.secret_key = os.urandom(32).hex()  # Set FLASK_SECRET_KEY in production for stable sessions
DB_PATH=os.environ.get("STUDENT_DB_PATH", os.path.join(os.path.dirname(__file__), "students.db"))
def db():
    con=sqlite3.connect(DB_PATH); con.row_factory=sqlite3.Row; return con
def init_db():
    with db() as con:
        con.execute("CREATE TABLE IF NOT EXISTS student_history (id INTEGER PRIMARY KEY AUTOINCREMENT, student_name TEXT NOT NULL, created_at TEXT NOT NULL, model TEXT NOT NULL, probability REAL NOT NULL, risk_level TEXT NOT NULL, status TEXT NOT NULL, attendance REAL, previous_grade REAL, assignments REAL, study_time INTEGER, absences INTEGER, proxy_label INTEGER NOT NULL)")
init_db()
FEATURES=["study_time","attendance","previous_grade","assignments","absences"]
MODELS={}; METRICS={}
def demo(n=500,seed=42):
 r=np.random.default_rng(seed); d=pd.DataFrame({"study_time":r.integers(1,5,n),"attendance":r.integers(45,101,n),"previous_grade":r.integers(4,21,n),"assignments":r.integers(20,101,n),"absences":r.integers(0,25,n)})
 points=(d.attendance<75).astype(int)+(d.previous_grade<10).astype(int)+(d.assignments<60).astype(int)+(d.study_time<=1).astype(int)+(d.absences>=10).astype(int)
 d["risk"]=(points>=2).astype(int); return d
def train(df=None):
 global MODELS,METRICS
 if df is None or len(df)<30 or "risk" not in df: df=demo()
 X=df[FEATURES]; y=df.risk.astype(int)
 if y.nunique()<2: df=demo(); X=df[FEATURES]; y=df.risk.astype(int)
 Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.25,random_state=42,stratify=y)
 ms={"Logistic Regression":make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000,class_weight="balanced")),"Decision Tree":DecisionTreeClassifier(max_depth=5,random_state=42,class_weight="balanced"),"Random Forest":RandomForestClassifier(n_estimators=150,max_depth=7,random_state=42,class_weight="balanced")}
 scores={}
 for n,m in ms.items():
  m.fit(Xtr,ytr); p=m.predict(Xte)
  scores[n]={"accuracy":round(accuracy_score(yte,p),3),"precision":round(precision_score(yte,p,zero_division=0),3),"recall":round(recall_score(yte,p,zero_division=0),3),"f1":round(f1_score(yte,p,zero_division=0),3),"matrix":confusion_matrix(yte,p).tolist()}
 MODELS,METRICS=ms,scores
def plan(s):
 p=[]; f=[]
 if s["previous_grade"]<10: p.append(("Academic foundation","Meet the subject teacher; identify 2–3 difficult topics and practise them for 20–30 minutes, five days a week.")); f.append("Grade is below 10/20: begin with foundational topics and short, frequent practice.")
 elif s["previous_grade"]<14: p.append(("Assessment improvement","Review mistakes, create a one-page topic summary, and complete two timed practice sets each week.")); f.append("There is room to improve the grade: focus on repeated mistakes and timed practice.")
 else: p.append(("Maintain progress","Keep a weekly revision schedule and attempt one challenging practice task each week.")); f.append("Current grade is a strength; maintain revision and consistency.")
 if s["attendance"]<75: p.append(("Attendance","Aim to attend every scheduled class for two weeks. If absences are unavoidable, tell the advisor and arrange catch-up notes.")); f.append(f"Attendance is {s['attendance']}%: discuss barriers and set a realistic goal.")
 else: f.append("Attendance is at or above the 75% review threshold.")
 if s["assignments"]<60: p.append(("Assignments","List pending work, agree on deadlines, and complete the most urgent task first using a weekly checklist.")); f.append(f"Assignment completion is {s['assignments']}%: split pending work into small tasks.")
 if s["study_time"]<=1: p.append(("Study routine","Start with 25-minute focused sessions and 5-minute breaks, four times a week; increase gradually.")); f.append("Study time is very low: start with a small, repeatable routine.")
 if s["absences"]>=10: p.append(("Catch-up support","Ask for notes from missed classes and list topics that need clarification.")); f.append(f"There are {s['absences']} absences: prioritise catching up.")
 if not p:p.append(("Stretch goal","Keep the current routine, check progress weekly, and ask for feedback on one advanced topic."))
 return p,f
train()
LOGIN_USERNAME = os.environ.get("APP_USERNAME", "")
LOGIN_PASSWORD = os.environ.get("APP_PASSWORD", "")

@app.route("/")
def home():
    if session.get("logged_in"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if LOGIN_USERNAME and LOGIN_PASSWORD and username == LOGIN_USERNAME and password == LOGIN_PASSWORD:
            session["logged_in"] = True
            session["username"] = username
            return redirect(url_for("dashboard"))
        flash("Sign-in failed. Check your configured credentials. If this is your first run, set APP_USERNAME and APP_PASSWORD as environment variables.")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/dashboard")
def dashboard():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    with db() as con:
        total=con.execute("SELECT COUNT(*) FROM student_history").fetchone()[0]
        recent=con.execute("SELECT * FROM student_history ORDER BY id DESC LIMIT 5").fetchall()
    return render_template("dashboard.html", metrics=METRICS, username=session.get("username", "user"), total_students=total, recent=recent)

@app.route("/predictor")
def predictor():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return render_template("index.html", metrics=METRICS)
@app.route("/predict",methods=["POST"])
def predict():
 if not session.get("logged_in"): return redirect(url_for("login"))
 try:
  s={"name":request.form.get("name","Student").strip() or "Student","study_time":int(request.form["study_time"]),"attendance":float(request.form["attendance"]),"previous_grade":float(request.form["previous_grade"]),"assignments":float(request.form["assignments"]),"absences":int(request.form["absences"])}
  if not(1<=s["study_time"]<=4 and 0<=s["attendance"]<=100 and 0<=s["previous_grade"]<=20 and 0<=s["assignments"]<=100 and s["absences"]>=0): raise ValueError("Values are outside allowed ranges.")
  name=request.form.get("model","Random Forest"); m=MODELS.get(name,MODELS["Random Forest"]); x=pd.DataFrame([[s[k] for k in FEATURES]],columns=FEATURES)
  risk=int(m.predict(x)[0]); prob=round(float(m.predict_proba(x)[0][1])*100,1); p,f=plan(s)
  level="High academic-risk estimate" if prob>=70 else ("Moderate academic-risk estimate" if prob>=40 else "Lower academic-risk signals")
  status="Needs review" if prob>=40 else "Monitoring"
  with db() as con:
   con.execute("INSERT INTO student_history (student_name,created_at,model,probability,risk_level,status,attendance,previous_grade,assignments,study_time,absences,proxy_label) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",(s["name"],datetime.now().strftime("%Y-%m-%d %H:%M"),name,prob,level,status,s["attendance"],s["previous_grade"],s["assignments"],s["study_time"],s["absences"],risk))
  return render_template("index.html",metrics=METRICS,result={"s":s,"risk":risk,"prob":prob,"level":level,"model":name,"plan":p,"feedback":f,"status":status})
 except Exception as e: flash("Check your values: "+str(e)); return redirect(url_for("predictor"))
@app.route("/upload",methods=["POST"])
def upload():
 if not session.get("logged_in"): return redirect(url_for("login"))
 file=request.files.get("file")
 if not file: flash("Choose a CSV file first."); return redirect(url_for("predictor"))
 try:
  d=pd.read_csv(file); d.columns=[str(c).strip().lower().replace(" ","_") for c in d.columns]
  required=set(FEATURES)
  if not required.issubset(d.columns): raise ValueError("CSV needs columns: "+", ".join(FEATURES))
  for c in FEATURES:d[c]=pd.to_numeric(d[c],errors="coerce")
  d=d.dropna(subset=FEATURES)
  if "risk" not in d:
   pts=(d.attendance<75).astype(int)+(d.previous_grade<10).astype(int)+(d.assignments<60).astype(int)+(d.study_time<=1).astype(int)+(d.absences>=10).astype(int); d["risk"]=(pts>=2).astype(int)
  if len(d)<30: raise ValueError("At least 30 valid rows are needed.")
  d["study_time"]=d.study_time.clip(1,4); d["attendance"]=d.attendance.clip(0,100); d["previous_grade"]=d.previous_grade.clip(0,20); d["assignments"]=d.assignments.clip(0,100); d["absences"]=d.absences.clip(lower=0)
  train(d); flash(f"Loaded {len(d)} rows and retrained models. The target is an academic-risk proxy unless your CSV has a verified risk label.")
 except Exception as e: flash("CSV upload failed: "+str(e))
 return redirect(url_for("predictor"))

@app.route("/history")
def history():
 if not session.get("logged_in"): return redirect(url_for("login"))
 with db() as con: rows=con.execute("SELECT * FROM student_history ORDER BY id DESC").fetchall()
 return render_template("history.html", rows=rows)

@app.route("/history/<int:record_id>/status", methods=["POST"])
def update_status(record_id):
 if not session.get("logged_in"): return redirect(url_for("login"))
 status=request.form.get("status", "")
 allowed={"Needs review","Support in progress","Monitoring","Resolved"}
 if status not in allowed:
  flash("Choose a valid student status.")
 else:
  with db() as con: con.execute("UPDATE student_history SET status=? WHERE id=?",(status,record_id))
  flash("Student follow-up status updated.")
 return redirect(url_for("history"))

@app.route("/sample.csv")
def sample():
 if not session.get("logged_in"): return redirect(url_for("login"))
 out=demo(40); out.insert(0,"student_id",[f"STU{i:03}" for i in range(1,41)]); r=make_response(out.to_csv(index=False)); r.headers["Content-Disposition"]="attachment; filename=student_sample.csv"; return r
@app.route("/metrics.csv")
def export():
 if not session.get("logged_in"): return redirect(url_for("login"))
 out=io.StringIO(); w=csv.writer(out); w.writerow(["model","accuracy","precision","recall","f1"])
 for n,m in METRICS.items(): w.writerow([n,m["accuracy"],m["precision"],m["recall"],m["f1"]])
 r=make_response(out.getvalue()); r.headers["Content-Disposition"]="attachment; filename=model_metrics.csv"; return r
if __name__=="__main__": app.run(debug=True)
