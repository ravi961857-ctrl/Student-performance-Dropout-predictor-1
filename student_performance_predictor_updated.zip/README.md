# Student Performance & Dropout Predictor

## Run on Windows
1. Install Python 3.10+ and extract this ZIP.
2. Configure login credentials privately in the terminal before launching `Run Website.bat`:
   ```bat
   set APP_USERNAME=your_username
   set APP_PASSWORD=your_strong_password
   set FLASK_SECRET_KEY=replace_with_a_long_random_secret
   "Run Website.bat"
   ```
   Use your own values; do not commit them to source control or share screenshots containing them. These variables apply to that Command Prompt session.
3. Double-click `Run Website.bat` from a terminal session where the variables are set. First run installs the required libraries.
4. Open http://127.0.0.1:5000. Keep the launcher window open.

If no `APP_USERNAME` and `APP_PASSWORD` are configured, login is intentionally disabled. Credentials are not shown on the sign-in page and are not stored in the source code. `FLASK_SECRET_KEY` should be set for a stable, secure session key. Student history is stored locally in `students.db`; protect that file and back it up securely if needed.

## Features
- Logistic Regression, Decision Tree and Random Forest model comparison.
- Academic-risk proxy estimate with explanations and a suggested support plan.
- Persistent student history: timestamp, selected model, proxy score, academic snapshot and follow-up status.
- Follow-up statuses: Needs review, Support in progress, Monitoring and Resolved.
- CSV upload/retraining and sample CSV download.
- Accuracy, precision, recall and F1 metrics export.

## Important model limitation
The built-in records are fictional and use a rule-based academic-risk proxy label, not verified dropout outcomes. The percentage shown is a model-estimated score for that proxy label; it is not the probability that a student will drop out. Status is a staff follow-up workflow label, not an automated judgment about the student. The UCI Student Performance dataset does not directly supply a dropout label. Use verified institutional outcomes before making any actual dropout prediction claims. Use real student data only with permission and suitable privacy protections.
